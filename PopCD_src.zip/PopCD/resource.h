//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PopCD.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_POPCD_DIALOG                102
#define IDC_CURSOR_HAND                 109
#define IDC_MAJIAN                      118
#define IDR_MAINFRAME                   128
#define IDR_POPUP                       130
#define IDD_OPTION                      132
#define IDC_COMBO_DEFAULT_DRIVE         1000
#define IDC_CHECK_POP_DISK              1001
#define IDC_STATIC_ABOUT                1003
#define IDC_STATIC_HOME                 1007
#define IDC_STATIC_MAIL                 1008
#define ID_POP_OPTION                   32771
#define ID_POP_EXIT                     32772
#define ID_POP_HELP                     32773
#define ID_OPEN_ALL                     32774
#define ID_POP_AUTO_START               32775
#define ID_CLOSE_ALL                    32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
