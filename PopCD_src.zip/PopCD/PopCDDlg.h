// PopCDDlg.h : header file
//

#if !defined(AFX_POPCDDLG_H__737F40C7_1C2A_11D3_BBDE_E19B8DC5C739__INCLUDED_)
#define AFX_POPCDDLG_H__737F40C7_1C2A_11D3_BBDE_E19B8DC5C739__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPopCDDlg dialog

class CPopCDDlg : public CDialog
{
// Construction
public:
	CPopCDDlg(CWnd* pParent = NULL);	// standard constructor

	BOOL TaskBarAddIcon();
	BOOL TaskBarDeleteIcon();
//	BOOL TaskBarModifyIcon(BOOL bIn);
	BOOL Create();
	BOOL CheckLink();
	void OnMenuMsg(CMenu& menu, int nID);

// Dialog Data
	//{{AFX_DATA(CPopCDDlg)
	enum { IDD = IDD_POPCD_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPopCDDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPopCDDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnPopExit();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnPopOption();
	afx_msg void OnPopAutoStart();
	afx_msg void OnPopHelp();
	afx_msg void OnAppAbout();
	afx_msg BOOL OnQueryEndSession();
	afx_msg void OnOpenAll();
	afx_msg void OnCloseAll();
	//}}AFX_MSG
	afx_msg LONG OnTrayNotification(UINT wParam, LONG lParam);
	afx_msg LONG OnTaskBarCreated(WPARAM wp, LPARAM lp);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_POPCDDLG_H__737F40C7_1C2A_11D3_BBDE_E19B8DC5C739__INCLUDED_)
