; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CPopCDApp
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "PopCD.h"

ClassCount=3
Class1=CPopCDApp
Class2=CPopCDDlg

ResourceCount=6
Resource2=IDD_POPCD_DIALOG
Resource3=IDD_OPTION (English (U.S.))
Resource4=IDD_POPCD_DIALOG (English (U.S.))
Resource1=IDR_MAINFRAME
Class3=CDlgOption
Resource5=IDD_ABOUTBOX (English (U.S.))
Resource6=IDR_POPUP (English (U.S.))

[CLS:CPopCDApp]
Type=0
HeaderFile=PopCD.h
ImplementationFile=PopCD.cpp
Filter=N
BaseClass=CWinApp
VirtualFilter=AC
LastObject=CPopCDApp

[CLS:CPopCDDlg]
Type=0
HeaderFile=PopCDDlg.h
ImplementationFile=PopCDDlg.cpp
Filter=D
LastObject=ID_CLOSE_ALL
BaseClass=CDialog
VirtualFilter=dWC



[DLG:IDD_POPCD_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CPopCDDlg

[DLG:IDD_POPCD_DIALOG (English (U.S.))]
Type=1
Class=CPopCDDlg
ControlCount=0

[MNU:IDR_POPUP (English (U.S.))]
Type=1
Class=?
Command1=ID_OPEN_ALL
Command2=ID_CLOSE_ALL
Command3=ID_POP_OPTION
Command4=ID_POP_AUTO_START
Command5=ID_POP_HELP
Command6=ID_APP_ABOUT
Command7=ID_POP_EXIT
CommandCount=7

[CLS:CDlgOption]
Type=0
HeaderFile=DlgOption.h
ImplementationFile=DlgOption.cpp
BaseClass=CDialog
Filter=D
LastObject=CDlgOption
VirtualFilter=dWC

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=11
Control1=IDC_STATIC,static,1342308353
Control2=IDOK,button,1342373889
Control3=IDC_STATIC,static,1342308352
Control4=IDC_STATIC,static,1342308352
Control5=IDC_STATIC,static,1342308354
Control6=IDC_STATIC_MAIL,static,1342308352
Control7=IDC_MAJIAN,static,1342308352
Control8=IDC_STATIC,static,1342308354
Control9=IDC_STATIC,static,1342308354
Control10=IDC_STATIC_HOME,static,1342308352
Control11=IDC_STATIC,static,1342179331

[DLG:IDD_OPTION (English (U.S.))]
Type=1
Class=CDlgOption
ControlCount=6
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Control4=IDC_COMBO_DEFAULT_DRIVE,combobox,1344339971
Control5=IDC_CHECK_POP_DISK,button,1342242819
Control6=IDC_STATIC_ABOUT,static,1342177283

