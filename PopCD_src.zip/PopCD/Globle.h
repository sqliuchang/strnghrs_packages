
extern char		g_chDefaultDrive;
extern BOOL		g_bPopWhenExit;

void WriteOption();
void ReadOption();
BOOL CheckRM(char chDrive);
void PopCD();
void PopCD(char chDrive);
void PushCD();
void PushCD(char chDrive);
void InsertCDMenu(CMenu& menu);
void GetVolumeName(LPCTSTR pszRoot, char* pszName);
void CD_OpenCloseDrive(BOOL bOpenDrive, TCHAR cDrive);
void CD_OpenCloseAllDrives(BOOL bOpenDrives);
