#include "stdafx.h"
#include "resource.h"		// main symbols
#include "Aboutbox.h"

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
    //{{AFX_DATA_INIT(CAboutDlg)
    //}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CAboutDlg)
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
    //{{AFX_MSG_MAP(CAboutDlg)
        // No message handlers
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CAboutDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_MailLink.SubclassDlgItem(IDC_STATIC_MAIL, this);
	m_MailLink.SetURL(_T("mailto:stronghorse_mj@hotmail.com"));
	
	m_HomeLink.SubclassDlgItem(IDC_STATIC_HOME, this);
	m_HomeLink.SetURL(_T("http://www.comicer.com/stronghorse/"));
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}
