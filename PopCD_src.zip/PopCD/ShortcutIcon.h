#if !defined(AFX_SHORTCUTICON_H__7B2A8B92_44D9_4DAB_BEAF_378E4EA0E61E__INCLUDED_)
#define AFX_SHORTCUTICON_H__7B2A8B92_44D9_4DAB_BEAF_378E4EA0E61E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ShortcutIcon.h : header file
//

BOOL IsShortcutCreated();
void ShortcutOpt(BOOL bCreateIt);

#endif // !defined(AFX_SHORTCUTICON_H__7B2A8B92_44D9_4DAB_BEAF_378E4EA0E61E__INCLUDED_)
