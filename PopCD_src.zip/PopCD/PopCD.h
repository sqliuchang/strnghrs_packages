// PopCD.h : main header file for the POPCD application
//

#if !defined(AFX_POPCD_H__737F40C5_1C2A_11D3_BBDE_E19B8DC5C739__INCLUDED_)
#define AFX_POPCD_H__737F40C5_1C2A_11D3_BBDE_E19B8DC5C739__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CPopCDApp:
// See PopCD.cpp for the implementation of this class
//

class CPopCDApp : public CWinApp
{
public:
	CPopCDApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPopCDApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CPopCDApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_POPCD_H__737F40C5_1C2A_11D3_BBDE_E19B8DC5C739__INCLUDED_)
